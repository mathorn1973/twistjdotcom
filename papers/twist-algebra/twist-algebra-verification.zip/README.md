# Exact finite checks for Twist Algebra

Unzip this supplement next to the deposited revision.tex. Use Python 3
with its standard library. The optional guide comparison requires Node.js.
Run the commands from the directory containing the extracted scripts.

    python -B verify_algebra.py
    python -B verify_independent.py

The first command writes algebra-checks.json. The second prints a separate
report using cyclic group-ring convolution and determinant norms.

On Windows PowerShell, compare the JavaScript guide model with the exact
oracle using:

    python -B verify_independent.py --guide-model (Get-Command node).Source

On POSIX shells:

    python -B verify_independent.py --guide-model "$(command -v node)"

The bounded computations supplement the proofs in the article.
See the accompanying LICENSE.txt.
