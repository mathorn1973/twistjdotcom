"""Independent finite checks for Twist Algebra; standard-library exact arithmetic.

The oracle uses five-cycle group-ring convolution, quotiented by the all-ones
relation, rather than the manuscript verifier's downward polynomial reduction.
Field norms are independently computed as 4-by-4 Leibniz determinants.  These
finite checks supplement the written proofs; they do not prove an unbounded
classification, Kronecker's theorem, the PID property, or a physical law.
"""
from fractions import Fraction
from functools import lru_cache
from itertools import permutations, product
import hashlib
import json
from pathlib import Path
import argparse
import subprocess

ZERO = (0, 0, 0, 0)
ONE = (1, 0, 0, 0)
JROOT = (0, 1, 0, 0)
PHI = (0, 0, -1, -1)
STEP = (1, 0, 1, 0)


def add(x, y):
    return tuple(a + b for a, b in zip(x, y))


def neg(x):
    return tuple(-a for a in x)


def mul(x, y):
    cyc = [0] * 5
    for i, a in enumerate(x):
        for j, b in enumerate(y):
            cyc[(i + j) % 5] += a * b
    return tuple(cyc[i] - cyc[4] for i in range(4))


def star(x):
    cyc = [0] * 5
    for i, a in enumerate(x):
        cyc[-i % 5] += a
    return tuple(cyc[i] - cyc[4] for i in range(4))


def power(x, n):
    assert isinstance(n, int) and n >= 0
    result = ONE
    for _ in range(n):
        result = mul(result, x)
    return result


def sum_ring(xs):
    result = ZERO
    for x in xs:
        result = add(result, x)
    return result


def inner(v, w):
    return sum_ring(mul(star(x), y) for x, y in zip(v, w))


def hermitian(v):
    return inner(v, v)


def real_pair(x):
    assert x[1] == 0 and x[2] == x[3], x
    return x[0], -x[2]


def fnorm(x):
    a, b = x
    return a * a + a * b - b * b


def fmul(x, y):
    a, b = x
    c, d = y
    return a * c + b * d, a * d + b * c + b * d


def fdiv(x, y):
    a, b = y
    n = fnorm(y)
    assert n != 0
    return fmul(x, (Fraction(a + b, n), Fraction(-b, n)))


def totally_nonnegative(x):
    a, b = x
    return 2 * a + b >= 0 and fnorm(x) >= 0


def delta_raw(v):
    return fnorm(real_pair(hermitian(v)))


def det_leibniz(rows):
    n = len(rows)
    ans = 0
    for perm in permutations(range(n)):
        term = -1 if sum(perm[i] > perm[j] for i in range(n)
                         for j in range(i + 1, n)) % 2 else 1
        for i, j in enumerate(perm):
            term *= rows[i][j]
        ans += term
    return ans


@lru_cache(maxsize=None)
def norm_k(x):
    basis = [tuple(int(i == j) for i in range(4)) for j in range(4)]
    columns = [mul(x, b) for b in basis]
    return det_leibniz(list(zip(*columns)))


def scale(v, u):
    return tuple(mul(u, x) for x in v)


def matrix_r(v):
    return tuple(tuple(mul(x, star(y)) for y in v) for x in v)


def mmul(a, b):
    return tuple(tuple(sum_ring(mul(a[i][k], b[k][j])
                                for k in range(len(b)))
                       for j in range(len(b[0]))) for i in range(len(a)))


def same_ray(v, w):
    sv, sw = hermitian(v), hermitian(w)
    rv, rw = matrix_r(v), matrix_r(w)
    return all(mul(sw, rv[i][j]) == mul(sv, rw[i][j])
               for i in range(len(v)) for j in range(len(v)))


def overlap(v, w):
    h = inner(v, w)
    return fdiv(real_pair(mul(star(h), h)),
                real_pair(mul(hermitian(v), hermitian(w))))


def hadamard(v):
    return add(v[0], v[1]), add(v[0], neg(v[1]))


def check_guide(node):
    """Optional direct cross-check of the actual JS model against this oracle."""
    source = """
    const m=require('./guide-model.js');
    const ids=['axis0','axis1',...Array.from({length:10},(_,i)=>'phase'+i)];
    const states=ids.map(id=>m.state(id));
    const pairs=ids.flatMap(a=>ids.map(b=>({a,b,result:m.overlap(a,b)})));
    process.stdout.write(JSON.stringify({states,pairs},(k,v)=>typeof v==='bigint'?String(v):v));
    """
    data = json.loads(subprocess.check_output([str(node), '-e', source],
                                             cwd=Path(__file__).parent, text=True))
    epsilon = neg(power(JROOT, 3))
    vectors = {'axis0': (ONE, ZERO), 'axis1': (ZERO, ONE)}
    vectors.update({f'phase{k}': (ONE, power(epsilon, k)) for k in range(10)})
    for state in data['states']:
        v = vectors[state['id']]
        assert tuple(tuple(map(int, x)) for x in state['vector']) == v
        assert int(state['height']) == delta_raw(v)
        assert tuple(map(int, state['pair']['s'])) == hermitian(v)
        assert tuple(tuple(tuple(map(int, x)) for x in row)
                     for row in state['pair']['R']) == matrix_r(v)
    for row in data['pairs']:
        result = row['result']
        exact = result['exact']
        expected = overlap(vectors[row['a']], vectors[row['b']])
        actual = (Fraction(int(exact['a']), int(exact['denominator'])),
                  Fraction(int(exact['b']), int(exact['denominator'])))
        assert actual == expected
        assert result['same'] == same_ray(vectors[row['a']], vectors[row['b']])
        assert result['orthogonal'] == (inner(vectors[row['a']], vectors[row['b']]) == ZERO)
    return {'status': 'passed', 'exact_states_and_stored_pairs': len(data['states']),
            'exact_ordered_overlaps_and_flags': len(data['pairs'])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--guide-model', type=Path, metavar='NODE',
                        help='Also compare the actual guide-model.js using this Node executable.')
    args = parser.parse_args()
    roots = tuple(signroot for n in range(5)
                  for signroot in (power(JROOT, n), neg(power(JROOT, n))))
    assert len(set(roots)) == 10
    assert power(JROOT, 5) == ONE
    assert mul(PHI, STEP) == JROOT
    assert mul(PHI, PHI) == add(PHI, ONE)

    # 625 independent determinant norms; direct two-place real norm agrees.
    box = list(product(range(-2, 3), repeat=4))
    for z in box:
        assert norm_k(z) == fnorm(real_pair(mul(z, star(z))))
        assert norm_k(z) >= 0 and ((norm_k(z) == 0) == (z == ZERO))
        v = (ONE, z)  # primitive without an ideal-gcd algorithm
        assert delta_raw(v) >= (1 + int(z != ZERO)) ** 2
        assert (delta_raw(v) == 4) == (z in roots)
    
    # Exhaustive small vector box, including nonprimitive vectors. The bound
    # holds for all integral vectors, although ray height needs primitivity.
    small = list(product(range(-1, 2), repeat=4))
    checked_vectors = equality_vectors = unit_columns = low_vectors = 0
    rays = ((ONE, ZERO), (ZERO, ONE)) + tuple((ONE, r) for r in roots)
    for v in product(small, repeat=2):
        if v == (ZERO, ZERO):
            continue
        checked_vectors += 1
        support = [x for x in v if x != ZERO]
        k = len(support)
        height = delta_raw(v)
        assert height >= k * k
        predicted_equality = (norm_k(support[0]) == 1 and
                              all(any(x == mul(support[0], r) for r in roots)
                                  for x in support))
        assert (height == k * k) == predicted_equality
        equality_vectors += int(height == k * k)
        unit_columns += int(hermitian(v) == ONE)
        assert height not in (2, 3)
        if height <= 4:
            low_vectors += 1
            assert sum(same_ray(v, r) for r in rays) == 1
    assert unit_columns == 20

    # Every one of the 144 ordered pairs of the twelve classified rays.
    # Exact projector identities, both real places' bounds and Hadamard
    # invariance are tested without float tolerances or physical assumptions.
    pair_count = 0
    for i, v in enumerate(rays):
        assert delta_raw(v) == (1 if i < 2 else 4)
        rv, sv = matrix_r(v), hermitian(v)
        assert mmul(rv, rv) == tuple(tuple(mul(sv, x) for x in row) for row in rv)
        assert sum_ring(rv[k][k] for k in range(2)) == sv
        assert same_ray(hadamard(hadamard(v)), v)
        for j, w in enumerate(rays):
            pair_count += 1
            p = overlap(v, w)
            assert totally_nonnegative(p)
            assert totally_nonnegative((1 - p[0], -p[1]))
            assert (p == (1, 0)) == (i == j)
            assert (p == (0, 0)) == (inner(v, w) == ZERO)
            assert same_ray(v, w) == (i == j)
            assert p == overlap(w, v)
            rr = mmul(rv, matrix_r(w))
            trace_rr = sum_ring(rr[k][k] for k in range(2))
            h = inner(v, w)
            assert trace_rr == mul(star(h), h)
            assert p == overlap(hadamard(v), hadamard(w))
            assert p == overlap(scale(v, STEP), scale(w, PHI))
    assert pair_count == 144
    assert overlap((ONE, ONE), (ONE, JROOT)) == (Fraction(1, 4), Fraction(1, 4))

    # Positive/negative J unit powers and the deliberately nonprimitive 2v.
    step_inverse = neg(add(JROOT, power(JROOT, 2)))
    units = tuple(power(STEP if n >= 0 else step_inverse, abs(n))
                  for n in range(-8, 9))
    scaling_cases = 0
    two = (2, 0, 0, 0)
    for v in rays:
        for u in units:
            scaling_cases += 1
            assert norm_k(u) == 1
            assert delta_raw(scale(v, u)) == delta_raw(v)
            assert same_ray(scale(v, u), v)
        assert same_ray(scale(v, two), v)
        assert delta_raw(scale(v, two)) == 16 * delta_raw(v)
    assert norm_k(two) == 16  # det(H)=-2 is not an O-unit
    assert hermitian(hadamard((ONE, ZERO))) == two
    assert delta_raw(hadamard((ONE, ZERO))) == 4
    assert delta_raw((ONE, ZERO)) == 1  # height is not H-invariant

    # All 200 two-dimensional monomial root matrices are exactly unitary.
    unitary_matrices = 0
    for permutation in permutations(range(2)):
        for r, s in product(roots, repeat=2):
            columns = tuple(tuple(root if i == permutation[j] else ZERO
                                  for i in range(2))
                            for j, root in enumerate((r, s)))
            assert all(inner(columns[i], columns[j]) == (ONE if i == j else ZERO)
                       for i in range(2) for j in range(2))
            unitary_matrices += 1
    assert unitary_matrices == 200

    src = Path(__file__).with_name('revision.tex')
    report = {
        'status': 'passed',
        'oracle': 'C5 group-ring convolution; regular-representation Leibniz determinants; exact Fraction arithmetic',
        'source_sha256': hashlib.sha256(src.read_bytes()).hexdigest() if src.exists() else None,
        'checks': {
            'determinant_norms_and_primitive_chart': len(box),
            'integral_two_coordinate_vectors_in_minus1_plus1_box': checked_vectors,
            'equality_vectors_in_box': equality_vectors,
            'height_at_most_four_vectors_in_box': low_vectors,
            'unit_norm_columns_in_box': unit_columns,
            'classified_rays': len(rays),
            'ordered_ray_pairs_projector_overlap_and_hadamard': pair_count,
            'unit_scalings': scaling_cases,
            'two_by_two_root_monomial_unitaries': unitary_matrices,
            'nonprimitive_scaling_counterexample': True,
            'hadamard_changes_height_but_preserves_overlap': True
        },
        'limits': 'Finite checks supplement written proofs; no exhaustive search of K-projective space, no physical validation.'
    }
    report['guide_model_crosscheck'] = check_guide(args.guide_model) if args.guide_model else 'not_requested'
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
