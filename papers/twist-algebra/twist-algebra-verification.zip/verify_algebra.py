#!/usr/bin/env python3
"""Exact finite checks for Twist Algebra; the manuscript carries the proofs.

Coordinates are reduced polynomials modulo 1+x+x²+x³+x⁴. No floating-point
condition is used. This is finite arithmetic evidence, not a census of K-rays.
"""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ZERO, ONE, JROOT = (0, 0, 0, 0), (1, 0, 0, 0), (0, 1, 0, 0)


def add(x, y):
    return tuple(a + b for a, b in zip(x, y))


def scale(n, x):
    return tuple(n * a for a in x)


def mul(x, y):
    product = [0] * 7
    for i, a in enumerate(x):
        for k, b in enumerate(y):
            product[i + k] += a * b
    for degree in range(6, 3, -1):
        leading = product[degree]
        for offset in range(1, 5):
            product[degree - offset] -= leading
        product[degree] = 0
    return tuple(product[:4])


def power(x, exponent):
    assert exponent >= 0
    result = ONE
    while exponent:
        if exponent % 2:
            result = mul(result, x)
        x = mul(x, x)
        exponent //= 2
    return result


def embedding(x, exponent):
    result = ZERO
    for degree, coefficient in enumerate(x):
        result = add(result, scale(coefficient, power(JROOT, degree * exponent)))
    return result


def conjugate(x):
    return embedding(x, 4)


def real_pair(x):
    assert x[1] == 0 and x[2] == x[3], ("not in real subfield", x)
    return x[0], -x[2]


def real_norm(x):
    a, b = real_pair(x)
    return a * a + a * b - b * b


def totally_nonnegative(x):
    a, b = real_pair(x)
    return 2 * a + b >= 0 and real_norm(x) >= 0


def norm(x):
    return real_norm(mul(x, conjugate(x)))


def inner(v, w):
    assert len(v) == len(w)
    out = ZERO
    for a, b in zip(v, w):
        out = add(out, mul(conjugate(a), b))
    return out


def outer(v):
    return [[mul(a, conjugate(b)) for b in v] for a in v]


def matmul(A, B):
    return [[sum_ring(mul(a, b) for a, b in zip(row, col))
             for col in zip(*B)] for row in A]


def sum_ring(values):
    out = ZERO
    for value in values:
        out = add(out, value)
    return out


def matrix_scale(x, A):
    return [[mul(x, a) for a in row] for row in A]


def trace(A):
    return sum_ring(A[i][i] for i in range(len(A)))


def same_ray(v, w):
    return matrix_scale(inner(w, w), outer(v)) == matrix_scale(inner(v, v), outer(w))


def check_pair(v):
    H, R = inner(v, v), outer(v)
    assert H != ZERO and totally_nonnegative(H)
    assert real_norm(H) > 0
    assert trace(R) == H
    assert matmul(R, R) == matrix_scale(H, R)
    assert R == [[conjugate(R[k][i]) for k in range(len(v))] for i in range(len(v))]


def run():
    phi = (0, 0, -1, -1)
    J = (1, 0, 1, 0)
    Jinv = (0, -1, -1, 0)
    assert power(JROOT, 5) == ONE
    assert mul(phi, phi) == add(phi, ONE)
    assert mul(J, phi) == JROOT and mul(J, Jinv) == ONE
    assert mul(J, conjugate(J)) == add(scale(2, ONE), scale(-1, phi))

    roots = [scale(sign, power(JROOT, r)) for sign in (1, -1) for r in range(5)]
    assert len(set(roots)) == 10 and all(power(x, 10) == ONE for x in roots)
    box = list(itertools.product(range(-2, 3), repeat=4))
    low_chart = []
    for a in box:
        assert conjugate(conjugate(a)) == a
        product = ONE
        for r in range(1, 5):
            product = mul(product, embedding(a, r))
        assert product == scale(norm(a), ONE)
        assert norm(a) >= 0 and (norm(a) == 0) == (a == ZERO)
        v = (ONE, a)  # primitive by construction
        check_pair(v)
        delta = real_norm(inner(v, v))
        assert delta >= (1 + (a != ZERO)) ** 2
        if delta <= 4:
            low_chart.append(a)
    assert set(low_chart) == {ZERO, *roots}

    rays = [(ONE, ZERO), (ZERO, ONE)] + [(ONE, eps) for eps in roots]
    assert len(rays) == 12
    overlaps = 0
    for i, v in enumerate(rays):
        check_pair(v)
        assert real_norm(inner(v, v)) == (1 if i < 2 else 4)
        for k, w in enumerate(rays):
            h = inner(v, w)
            numerator, denominator = mul(h, conjugate(h)), mul(inner(v, v), inner(w, w))
            assert numerator == trace(matmul(outer(v), outer(w)))
            assert totally_nonnegative(numerator)
            assert totally_nonnegative(add(denominator, scale(-1, numerator)))
            assert (numerator == denominator) == (i == k) == same_ray(v, w)
            overlaps += 1

    v, w = (ONE, ONE), (ONE, JROOT)
    assert mul(inner(v, w), conjugate(inner(v, w))) == add(ONE, phi)
    assert mul(inner(v, v), inner(w, w)) == scale(4, ONE)
    assert inner((ONE, ONE), (ONE, scale(-1, ONE))) == ZERO

    scaling_checks = 0
    for n in range(-6, 7):
        u = power(J if n >= 0 else Jinv, abs(n))
        for seed in (rays[0], rays[3], (ONE, phi), (ONE, scale(2, ONE))):
            changed = tuple(mul(u, x) for x in seed)
            check_pair(changed)
            assert same_ray(seed, changed)
            assert real_norm(inner(seed, seed)) == real_norm(inner(changed, changed))
            scaling_checks += 1
    for support in range(1, 7):
        seed = tuple(roots[r] for r in range(support))
        assert real_norm(inner(seed, seed)) == support ** 2
        changed = tuple(mul(J, a) for a in seed)
        assert real_norm(inner(changed, changed)) == support ** 2

    A = [[ONE, ONE], [ONE, scale(-1, ONE)]]
    assert matmul(A, A) == [[scale(2, ONE), ZERO], [ZERO, scale(2, ONE)]]
    moved = (ONE, ONE)
    returned = (scale(2, ONE), ZERO)
    assert same_ray(rays[0], returned)
    assert real_norm(inner(rays[0], rays[0])) == 1
    assert real_norm(inner(moved, moved)) == 4
    assert real_norm(inner(returned, returned)) == 16
    assert not same_ray(rays[0], moved)

    result = {
        "status": "passed",
        "source_sha256": hashlib.sha256((ROOT / "revision.tex").read_bytes()).hexdigest(),
        "arithmetic": "Integer polynomial multiplication with downward Phi_5 reduction; no floating-point assertions",
        "cyclotomic_norm_and_primitive_chart_cases": len(box),
        "pairwise_low_height_overlap_cases": overlaps,
        "unit_scaling_cases": scaling_checks,
        "equality_support_sizes": [1, 2, 3, 4, 5, 6],
        "additional_checks": ["conjugation involution", "all four embedding product versus real quadratic norm", "Hermitian rank-one matrix identities", "both-place overlap bounds", "exact phi-squared-over-four example", "Hadamard involution and nonprimitive return"],
        "scope": "Finite exact checks support the manuscript. The complete ray classification and rigidity follow from its proofs, not a finite box census."
    }
    (ROOT / "algebra-checks.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(box)} exact norm/chart cases, {overlaps} overlaps, {scaling_checks} unit scalings, six equality support sizes, pair identities and Hadamard boundary.")


if __name__ == "__main__":
    run()
